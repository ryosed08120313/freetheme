/**
 * 
 */
$(function(){
	// マウスオーバー
	$(".card-hover").hover(function(){
		//ホバー部の追加
		$(this).append("<div class=\"white-text hover-primary\"><p>" + $(this).children("input").attr("alt") + "</p></div>");
		
		//ホバー表示
		$(this).children("div").stop().fadeIn(300);
		
		//テキスト位置移動
		$(this).children("div").children("p").stop().animate({"top" : 0}, 300);
		
	}, function(){
		//非表示・フェードアウト
		$(this).children("div").stop().fadeOut({"top" : 0}, 300);
		
		//テキスト位置移動
		$(this).children("div").children("p").stop().animate({"top" : 0}, 300,
		function(){
			$(this).parent("div").remove();
		});
	});
});
