package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import constants.ConstURL;
import dao.ProductDAO;
import ds.ConnectionManager;

/**
 * 予約履歴詳細画面表示用サーブレット
 */
@WebServlet("/DisplayReservationHistoryDetailServlet")
public class DisplayReservationHistoryDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String productId = request.getParameter("productId");
		ConnectionManager connectionManager = new ConnectionManager();
		session.getAttribute("rese");

		Product product = new Product();

		try (
				// コネクションを取得
				Connection con = connectionManager.getConnection();) {

			// ReservationDAOのインスタンスを生成
			ProductDAO productDAO = new ProductDAO(con);

			// ProductDAOからselectByIdを呼び出しproductListに入れる。
			product = productDAO.selectById(productId);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NamingException e) {
			e.printStackTrace();
		}

		session.setAttribute("product", product);

		String url = ConstURL.DISPLAY_RESERVATION_HISTORY_DETAIL_PATH;

		request.getRequestDispatcher(url).forward(request, response);

	}

}
