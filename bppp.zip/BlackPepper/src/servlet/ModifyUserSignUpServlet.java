package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import constants.ConstURL;

/**
 * ユーザー登録情報修正用サーブレット
 */
@WebServlet("/ModifyUserSignUpServlet")
public class ModifyUserSignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Memberのインスタンス生成
		Member member = new Member();
		// ユーザー情報のパラメーター取得
		String lastName = request.getParameter("lastName");
		String firstName = request.getParameter("firstName");
		String lastNameKana = request.getParameter("lastNameKana");
		String firstNameKana = request.getParameter("firstNameKana");
		String password = request.getParameter("password");
		String phoneNum = request.getParameter("phoneNum");
		String eMail = request.getParameter("eMail");
		String zip = request.getParameter("zip");
		String address = request.getParameter("address");
		// カード情報
		String creditCardNum = request.getParameter("creditCardNum");
		// カード期限
		String creditCardValidMonth = request.getParameter("creditCardValidMonth");
		String creditCardValidYear = request.getParameter("creditCardValidYear");

		String creditCardSecurityCord = request.getParameter("creditCardSecurityCord");
		String creditCardName = request.getParameter("creditCardName");
		// パスポート
		String passportName = request.getParameter("passportName");
		String passportNum = request.getParameter("passportNum");

		// Memberのインスタンスに情報をセット

		member.setPassword(password);
		member.setPhoneNum(phoneNum);
		member.setZip(zip);
		member.setAddress(address);
		member.seteMail(eMail);
		member.setCreditCardName(creditCardName);
		member.setCreditCardNum(creditCardNum);
		member.setCreditCardSecurityCord(creditCardSecurityCord);
		member.setCreditCardValidMonth(creditCardValidMonth);
		member.setCreditCardValidYear(creditCardValidYear);
		member.setPassportName(passportName);
		member.setPassportNum(passportNum);
		String url = ConstURL.DISPLAY_USER_SIGN_UP_PATH;
		HttpSession session = request.getSession();
		session.setAttribute("member", member);
		session.setAttribute("lastName", lastName);
		session.setAttribute("lastNameKana", lastNameKana);
		session.setAttribute("firstName", firstName);
		session.setAttribute("firstNamekana", firstNameKana);
		request.getRequestDispatcher(url).forward(request, response);
	}
}