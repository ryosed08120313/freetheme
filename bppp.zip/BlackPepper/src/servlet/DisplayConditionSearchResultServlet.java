package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Product;
import constants.ConstURL;
import dao.ProductDAO;
import ds.ConnectionManager;

/**
 * 条件検索結果画面表示サーブレット
 */
@WebServlet("/DisplayConditionSearchResultServlet")
public class DisplayConditionSearchResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("サーブレットINああああ");
		String url = ConstURL.DISPLAY_CONDITION_SEARCH_RESULT_PATH;

		// 各種パラメータ値受け取る
		String country = request.getParameter("country");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		int minPrice = Integer.parseInt(request.getParameter("minPrice"));
		int maxPrice = Integer.parseInt(request.getParameter("maxPrice"));

		System.out.println("サーブレットIN前");
		System.out.println(country);
		System.out.println(startDate);
		System.out.println(endDate);
		System.out.println(minPrice);
		System.out.println(maxPrice);

		System.out.println("サーブレットIN後ろ");
		Timestamp startDateTime = null;
		Timestamp endDateTime = null;

		List<Product> productList = null;

		try {
			startDateTime = new Timestamp(new SimpleDateFormat("yyyy/MM/dd").parse(startDate).getTime());
			endDateTime = new Timestamp(new SimpleDateFormat("yyyy/MM/dd").parse(endDate).getTime());

		} catch (ParseException e) {
			e.printStackTrace();
		}

		System.out.println(startDateTime);
		System.out.println(endDateTime);

		try (Connection con = ConnectionManager.getConnection()) {
			System.out.println("tryの中");
			ProductDAO productDAO = new ProductDAO(con);

			// productbean生成、各項目セット

			Product product = new Product();

			product.setRemarks(country);
			product.setDepartureTime(startDateTime);
			product.setArriveTime(endDateTime);

			productList = productDAO.selectAll(product, maxPrice, minPrice);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}

		request.setAttribute("productList", productList);

		request.getRequestDispatcher(url).forward(request, response);
	}

}
