package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Member;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * Servlet implementation class UpdataMemberServlet
 */
@WebServlet("/UpdataMemberServlet")
public class UpdataMemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);

		HttpSession session = request.getSession();

	try (Connection con = ConnectionManager.getConnection()) {
			Member member = new Member();
			member.setId(request.getParameter("id"));
			member.setAddress(request.getParameter("address"));
			member.setZip(request.getParameter("zip"));
			member.setPhoneNum(request.getParameter("phoneNum"));
			member.setCreditCardNum(request.getParameter("creditCardNum"));
			member.setCreditCardName(request.getParameter("creditCardName"));
			member.setCreditCardValidMonth(request.getParameter("creditCardValidMonth"));
			member.setCreditCardValidYear(request.getParameter("creditCardValidYear"));
			member.setCreditCardSecurityCord(request.getParameter("creditCardSecurityCord"));
			
			MembersDAO memberesDAO = new MembersDAO(con);
			memberesDAO.update(member);



	} catch (NamingException e) {
		throw new ServletException(e);

	} catch (SQLException e) {

		throw new ServletException(e);
	
}
	
	}}
