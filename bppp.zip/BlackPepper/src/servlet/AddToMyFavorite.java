package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import constants.ConstURL;
import dao.FavoriteDAO;
import ds.ConnectionManager;

/**
 * 商品詳細ページからお気に入りボタン押したときに動く。 お気に入りに追加して元の商品詳細ページへ戻る
 */
@WebServlet("/AddToMyFavorite")
public class AddToMyFavorite extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		String memberId = (String) session.getAttribute("userId_tmp");
		if (memberId == null) {
			request.getRequestDispatcher("/WEB-INF/P01031.jsp").forward(request, response);
			return;
		}

		String favoriteId = "";

		String itineraryId = request.getParameter("itineraryId");
		if (!(itineraryId == null)) {
			favoriteId = (memberId + itineraryId);
		}
		System.out.println(favoriteId);

		String spotId = request.getParameter("spotId");
		if (!(spotId == null)) {
			favoriteId = (memberId + spotId);
		}
		System.out.println(favoriteId);

		String productId = request.getParameter("productId");
		if (!(productId == null)) {
			favoriteId = (memberId + productId);
		}

		System.out.println(favoriteId);

		int cnt = 0;

		String url = ConstURL.DISPLAY_PRODUCT_DETAIL_PATH;

		/**
		 * お気に入りに追加する作業
		 * 
		 * ユーザーIDと各IDをDAOにわたし、お気に入りに追加する
		 * 
		 */

		try (Connection con = ConnectionManager.getConnection()) {

			// DAO生成して、IDもとにbean受け取る
			FavoriteDAO favoriteDAO = new FavoriteDAO(con);

			cnt = favoriteDAO.insert(favoriteId, itineraryId, spotId, productId, memberId);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}
		System.out.println(cnt);
		if (cnt == 1) {
			request.setAttribute("message", "一件お気に入りに登録しました。");
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
}
