package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Comment;
import bean.Member;
import constants.ConstURL;
import dao.CommentDAO;
import ds.ConnectionManager;

@WebServlet("/AddCommentServlet")
public class AddCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		List<Comment> commentL = (List<Comment>) session.getAttribute("commentList");
		String memberId = (String) session.getAttribute("userId_tmp");
		if (memberId == null) {
			request.getRequestDispatcher("/WEB-INF/P01031.jsp").forward(request, response);
			return;
		}

		int cnt = 0;
		String url = ConstURL.DISPLAY_SPOT_DETAIL_PATH;
		/**
		 * コメント追加 メンバーＩＤ等をDAOに渡し、コメント追加
		 */

		try (Connection con = ConnectionManager.getConnection()) {
			Comment comment = new Comment();
			Member member = (Member) session.getAttribute("afterloginmember");
			System.out.println(member.getId() + "IDだお");
			Timestamp nowTime = new Timestamp(new Date().getTime());
			String commentId = member.getId() + nowTime;

			comment.setCommentId(commentId);
			comment.setCommentContent(request.getParameter("commentContent"));
			comment.setMemberId(member.getId());
			comment.setCommentTime(nowTime);
			comment.setSpotId(request.getParameter("addedSpotId"));
			comment.setGrade(Integer.parseInt(request.getParameter("grade")));
			comment.setItineraryId(request.getParameter("itineraryId"));
			comment.setProductId(request.getParameter("productId"));
			comment.setMemberName(member.getName());
			System.out.println("----Name----");
			System.out.println(member.getName());
			System.out.println("----Name----");
			commentL.add(comment);
			System.out.println("commentLのなかみ:" + commentL.get(0).getMemberName());
			session.setAttribute("commentLista", commentL);
			System.out.println(comment);
			CommentDAO commentDAO = new CommentDAO(con);
			cnt = commentDAO.insert(con, comment);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}
		System.out.println(cnt);
		if (cnt == 1) {
			request.setAttribute("message", "コメントを投稿しました。");
		}
		request.getRequestDispatcher("/DisplaySpotDetailServlet").forward(request, response);

	}

}
