package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberTopThree;
import constants.ConstURL;

/**
 * 他ユーザー詳細情報画面表示用サーブレット
 */
@WebServlet("/DisplayOtherUserDetailServlet")
public class DisplayOtherUserDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String url = ConstURL.DISPLAY_OTHER_USER_DETAIL_PATH;
		HttpSession session = request.getSession();
		MemberTopThree memberTop = (MemberTopThree) session.getAttribute("memberTop");
		MemberTopThree memberSecond = (MemberTopThree) session.getAttribute("memberSecond");
		MemberTopThree memberthird = (MemberTopThree) session.getAttribute("memberthird");
		String userRank = request.getParameter("userRank");
		int rank;
		if (userRank.equals("top")) {
			rank = 1;
			session.setAttribute("rank", rank);
			session.setAttribute("memberTop", memberTop);
			request.getRequestDispatcher(url).forward(request, response);
			return;

		} else if (userRank.equals("second")) {
			rank = 2;
			session.setAttribute("rank", rank);
			session.setAttribute("memberSecond", memberSecond);
			request.getRequestDispatcher(url).forward(request, response);
			return;
		} else {
			rank = 3;
			session.setAttribute("rank", rank);
			session.setAttribute("memberthird", memberthird);
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
}
