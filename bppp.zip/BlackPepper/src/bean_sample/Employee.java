package bean_sample;

import java.io.Serializable;

/**
 * @author yokin 従業員Bean
 */
public class Employee implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 従業員ID
	 */
	private String id;
	/**
	 * 従業員名
	 */
	private String name;
	/**
	 * 従業員年齢
	 */
	private int age;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + "]";
	}

}
