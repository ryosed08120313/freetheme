package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Itinerary;

/**
 * 旅程表DAO
 *
 * @author yokin
 */

public class ItineraryDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public ItineraryDAO(Connection con) {
		this.con = con;
	}

	public int insert(Itinerary itinerary) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO ITINERARY(ITINERARY_ID, MEMBER_ID, ITINERARY_NAME, CREATE_TIME, ITINERARY_OVERVIEW, COUNTRY_ID, COUNTRY_NAME )"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?)";
		System.out.println("itinerary:" + itinerary);
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, itinerary.getItineraryId());
			ps.setString(2, itinerary.getMemberId());
			ps.setString(3, itinerary.getItineraryName());
			ps.setTimestamp(4, itinerary.getCreateTime());
			ps.setString(5, itinerary.getItineraryOverview());
			ps.setString(6, itinerary.getCountryId());
			ps.setString(7, itinerary.getCountryName());

			cnt = ps.executeUpdate();
			System.out.println("INSERT INTO ITINERARY:" + cnt);
		}
		return cnt;
	}

	public int updateNameAndContent(Itinerary itinerary) throws SQLException {

		int cnt = 0;
		String sql = "UPDATE ITINERARY SET ITINERARY_NAME = ?, ITINERARY_OVERVIEW = ? WHERE ITINERARY_ID = ?";

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, itinerary.getItineraryName());
			ps.setString(2, itinerary.getItineraryOverview());
			ps.setString(3, itinerary.getItineraryId());
			cnt = ps.executeUpdate();

		}
		return cnt;

	}

	public List<Itinerary> selectByMemberId(String userId) throws SQLException {

		String sql = "SELECT * FROM ITINERARY WHERE MEMBER_ID = ? AND ITINERARY_NAME IS NOT NULL ORDER BY CREATE_TIME";
		List<Itinerary> list = new ArrayList<Itinerary>();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, userId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Itinerary itinerary = new Itinerary();
					itinerary.setMemberId(rs.getString("MEMBER_ID"));
					itinerary.setCreateTime(rs.getTimestamp("CREATE_TIME"));
					itinerary.setCountryId(rs.getString("COUNTRY_ID"));
					itinerary.setItineraryId(rs.getString("ITINERARY_ID"));
					itinerary.setItineraryOverview(rs.getString("ITINERARY_OVERVIEW"));
					itinerary.setItineraryName(rs.getString("ITINERARY_NAME"));
					itinerary.setCountryName(rs.getString("COUNTRY_NAME"));

					list.add(itinerary);
				}
			}
		}
		return list;
	}

	public Itinerary selectByItineraryId(String itineraryId) throws SQLException {

		String sql = "SELECT * FROM ITINERARY WHERE ITINERARY_ID =?";
		List<Itinerary> list = new ArrayList<Itinerary>();
		Itinerary itinerary=null;
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, itineraryId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					itinerary=new Itinerary();
					itinerary.setMemberId(rs.getString("MEMBER_ID"));
					itinerary.setCreateTime(rs.getTimestamp("CREATE_TIME"));
					itinerary.setCountryId(rs.getString("COUNTRY_ID"));
					itinerary.setItineraryId(rs.getString("ITINERARY_ID"));
					itinerary.setItineraryOverview(rs.getString("ITINERARY_OVERVIEW"));
					itinerary.setItineraryName(rs.getString("ITINERARY_NAME"));
					itinerary.setCountryName(rs.getString("COUNTRY_NAME"));

				}
			}
		}
		return itinerary;
	}


	// public int delete(String ItineraryId) throws SQLException {
	//
	// int cnt = 0;
	// String sql = "DELETE FROM ITINERARY WHERE ITINERARY_ID = ?";
	//
	// Itinerary itinerary = new Itinerary();
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	//
	// ps.setString(1, itinerary.());
	// cnt = ps.executeUpdate();
	// }

}