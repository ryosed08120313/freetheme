package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Category;

/**
 * オプショナルツアーDAO
 *
 * @author yokin
 */

public class CategoryDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public CategoryDAO(Connection con) {
		this.con = con;
	}

	public Category selectByCategoryId(String categoryId) throws SQLException {
		Category category = null;
		String sql = "SELECT * FROM CATEGORY WHERE CATEGORY_ID =?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, categoryId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					category = new Category();
					category.setCategoryId(rs.getString("CATEGORY_ID"));
					category.setCategoryName(rs.getString("CATEGORY_NAME"));

				}
			}
		}
		return category;
	}

}