package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Member;
import bean.Spot;

/**
 * スポットDAO
 *
 * @author yokin
 */

public class SpotDAO {

	private Connection con;

	/**
	 * コンストラクタ
	 *
	 * @param コネクション
	 */
	public SpotDAO(Connection con) {
		this.con = con;
	}

	public int insert(Spot spot) throws SQLException {
		int cnt = 0;
		String sql = "INSERT INTO SPOT(SPOT_ID, SPOT_NAME, MEMBER_ID, CITY_ID, TOUR1_ID, TOUR2_ID, TOUR3_ID, SPOT_CONTENT,CATEGORY1_ID,CATEGORY2_ID,CATEGORY3_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID)"
				+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, spot.getSpotId());
			ps.setString(2, spot.getSpotName());
			ps.setString(3, spot.getMemberId());
			ps.setString(4, spot.getCityId());
			ps.setString(5, spot.getTour1Id());
			ps.setString(6, spot.getTour2Id());
			ps.setString(7, spot.getTour3Id());
			ps.setString(8, spot.getSpotContent());
			ps.setString(9, spot.getCategory1Id());
			ps.setString(10, spot.getCategory2Id());
			ps.setString(11, spot.getCategory3Id());
			ps.setString(12, spot.getCategory4Id());
			ps.setString(13, spot.getCategory5Id());
			ps.setString(14, spot.getCategory6Id());

			cnt = ps.executeUpdate();
		}
		return cnt;
	}

	public List<Spot> selectAll() throws SQLException {
		String sql = "SELECT * FROM SPOT ORDER BY SPOT";
		List<Spot> list = new ArrayList<Spot>();
		try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Spot spot = new Spot();
				spot.setSpotId(rs.getString("SPOT_ID"));
				spot.setSpotName(rs.getString("SPOT_NAME"));
				spot.setMemberId(rs.getString("MEMBER_ID"));
				spot.setCityId(rs.getString("CITY_ID"));
				spot.setTour1Id(rs.getString("TOUR1_ID"));
				spot.setTour2Id(rs.getString("TOUR2_ID"));
				spot.setTour3Id(rs.getString("TOUR3_ID"));
				spot.setSpotContent(rs.getString("SPOT_CONTENT"));
				spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
				spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
				spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
				spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
				spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
				spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
				spot.setCountryName(rs.getString("COUNTRY_NAME"));
				list.add(spot);
			}
		}
		return list;
	}

	public List<Spot> selectAll(Member member) throws SQLException {
		String sql = "select * from spot where spot_id in(SELECT sp.spot_id FROM comment_inf co left outer join SPOT sp on sp.spot_id = co.spot_id group by sp.spot_id having  AVG(co.grade) <= ?)";
		List<Spot> list = new ArrayList<Spot>();
		try (PreparedStatement ps = con.prepareStatement(sql);) {
			ps.setDouble(1, member.getLimitView());
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
			return list;
		}
	}

	public Spot selectById(String id) throws SQLException {
		Spot spot = null;
		String sql = "SELECT * FROM SPOT s LEFT OUTER JOIN LATLON l ON s.LATLON_ID = l.LATLON_ID WHERE s.SPOT_ID = ?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					// 緯度経度を追加（倉田）
					spot.setLatLon(rs.getString("LATLON_VALUE"));
				}
			}
		}
		return spot;
	}

	public String DisplaySpotNameById(String id) throws SQLException {
		Spot spot = null;
		String spotName = null;
		String sql = "SELECT *FROM SPOT WHERE SPOT_ID =?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					spot = new Spot();

					spotName = rs.getString("SPOT_NAME");

				}
			}
		}
		return spotName;
	}

	public List<String> displaySpotNameBySpotId(String id) throws SQLException {
		String spotName = null;
		List<String> spotNameList = new ArrayList<String>();

		String sql = "SELECT * FROM SPOT WHERE MEMBER_ID =?";
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					spotName = rs.getString("SPOT_NAME");
				}
				spotNameList.add(spotName);
			}
		}
		return spotNameList;
	}

	public List<Spot> selectByName(String Name, Member member) throws SQLException {

		String sql = "SELECT * FROM SPOT WHERE (SPOT_NAME LIKE '%'||?||'%') and (spot_id in(SELECT sp.spot_id FROM spot sp left outer join comment_inf co on sp.spot_id = co.spot_id group by sp.spot_id having  AVG(NVL(co.grade,0)) <= ?))";
		List<Spot> list = new ArrayList<Spot>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, Name);
			ps.setDouble(2, member.getLimitView());
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
		}
		return list;
	}

	public List<Spot> selectByName(String Name) throws SQLException {

		String sql = "SELECT * FROM SPOT WHERE SPOT_NAME LIKE '%'||?||'%' ";
		List<Spot> list = new ArrayList<Spot>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, Name);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
		}
		return list;
	}

	public List<Spot> selectByMemberId(String userId) throws SQLException {

		String sql = "SELECT * FROM SPOT WHERE MEMBER_ID =?";
		List<Spot> list = new ArrayList<Spot>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, userId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
		}
		return list;
	}

	public List<Spot> selectByName(String Name, String[] genre) throws SQLException {

		String sql = "SELECT * FROM SPOT WHERE SPOT_NAME LIKE '%'||?||'%' AND (? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID))";
		List<Spot> list = new ArrayList<Spot>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, Name);
			ps.setString(2, genre[0]);
			ps.setString(3, genre[1]);
			ps.setString(4, genre[2]);

			ps.setString(5, genre[3]);
			ps.setString(6, genre[4]);
			ps.setString(7, genre[5]);
			ps.setString(8, genre[6]);
			ps.setString(9, genre[7]);
			ps.setString(10, genre[8]);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
		}
		return list;
	}

	public List<Spot> selectByName(String Name, Member member, String[] genre) throws SQLException {

		String sql = "SELECT * FROM SPOT WHERE (SPOT_NAME LIKE '%'||?||'%') and (spot_id in(SELECT sp.spot_id FROM spot sp left outer join comment_inf co on sp.spot_id = co.spot_id group by sp.spot_id having  AVG(NVL(co.grade,0)) <= ?) and (? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID) OR  ? in (CATEGORY1_ID,CATEGORY2_ID,CATEGORY4_ID,CATEGORY5_ID,CATEGORY6_ID)))";
		List<Spot> list = new ArrayList<Spot>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, Name);
			ps.setDouble(2, member.getLimitView());
			ps.setString(3, genre[0]);
			ps.setString(4, genre[1]);
			ps.setString(5, genre[2]);
			ps.setString(6, genre[3]);
			ps.setString(7, genre[4]);
			ps.setString(8, genre[5]);
			ps.setString(9, genre[6]);
			ps.setString(10, genre[7]);
			ps.setString(11, genre[8]);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Spot spot = new Spot();
					spot.setSpotId(rs.getString("SPOT_ID"));
					spot.setSpotName(rs.getString("SPOT_NAME"));
					spot.setMemberId(rs.getString("MEMBER_ID"));
					spot.setCityId(rs.getString("CITY_ID"));
					spot.setTour1Id(rs.getString("TOUR1_ID"));
					spot.setTour2Id(rs.getString("TOUR2_ID"));
					spot.setTour3Id(rs.getString("TOUR3_ID"));
					spot.setSpotContent(rs.getString("SPOT_CONTENT"));
					spot.setCategory1Id(rs.getString("CATEGORY1_ID"));
					spot.setCategory2Id(rs.getString("CATEGORY2_ID"));
					spot.setCategory3Id(rs.getString("CATEGORY3_ID"));
					spot.setCategory4Id(rs.getString("CATEGORY4_ID"));
					spot.setCategory5Id(rs.getString("CATEGORY5_ID"));
					spot.setCategory6Id(rs.getString("CATEGORY6_ID"));
					spot.setCountryName(rs.getString("COUNTRY_NAME"));
					list.add(spot);
				}
			}
		}
		return list;
	}

}