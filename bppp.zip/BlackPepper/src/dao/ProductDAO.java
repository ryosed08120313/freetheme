package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Product;

/**
 * 
 * @author SUZUKI
 *
 */
public class ProductDAO {

	public ProductDAO() {
	}

	private Connection con;

	/**
	 * コンストラクタ.コネクションゲット
	 * 
	 * @param コネクション
	 */
	public ProductDAO(Connection con) {
		this.con = con;
	}

	public List<Product> selectAll(Product product, int maxValue, int minValue) throws SQLException {
		String sql = "SELECT * FROM PRODUCT WHERE REMARKS=? AND DEPARTURE_TIME=? AND ARRIVAL_TIME=? AND PRODUCT_PRICE>=? AND PRODUCT_PRICE<=?";
		System.out.println("DAOIN");
		List<Product> list = new ArrayList<Product>();
		try (PreparedStatement ps = con.prepareStatement(sql);) {

			// 各項目セット。beanからと最低金額、最高金額
			ps.setString(1, product.getRemarks());
			ps.setTimestamp(2, product.getDepartureTime());
			ps.setTimestamp(3, product.getArriveTime());
			ps.setInt(4, minValue);
			ps.setInt(5, maxValue);

			System.out.println(product.getRemarks());
			System.out.println(product.getDepartureTime());
			System.out.println(product.getArriveTime());
			System.out.println(minValue);
			System.out.println(maxValue);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				// bean生成してそれぞれセット
				Product newProduct = new Product();

				newProduct.setProductId(rs.getString("PRODUCT_ID"));
				newProduct.setProductName(rs.getString("PRODUCT_NAME"));
				newProduct.setProductDetail(rs.getString("PRODUCT_CONTENT"));
				newProduct.setProductPrice(rs.getString("PRODUCT_PRICE"));
				newProduct.setAirportTax(rs.getString("AIRPORT_TAX"));
				newProduct.setCurrencyUnit(rs.getString("CURRENCY_UNIT"));
				newProduct.setExchangeRate(rs.getString("EXCHANGE_RATE"));
				newProduct.setMinimumNumber(rs.getString("MINIMUM_NUMBER"));
				newProduct.setStockQuantity(rs.getString("STOCK_QUANTITY"));
				newProduct.setRemarks(rs.getString("REMARKS"));
				newProduct.setUpdateTime(rs.getTimestamp("UPDATE_TIME"));
				newProduct.setDepartureTime(rs.getTimestamp("DEPARTURE_TIME"));
				newProduct.setArriveTime(rs.getTimestamp("ARRIVAL_TIME"));

				list.add(newProduct);
			}
		}
		return list;
	}

	public Product selectById(String id) throws SQLException {
		String sql = "SELECT *FROM PRODUCT WHERE PRODUCT_ID LIKE '%'||?||'%' ";
		Product product = new Product();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					product.setProductId(rs.getString("PRODUCT_ID"));
					product.setProductName(rs.getString("PRODUCT_NAME"));
					product.setProductDetail(rs.getString("PRODUCT_CONTENT"));
					product.setProductPrice(rs.getString("PRODUCT_PRICE"));
					product.setAirportTax(rs.getString("AIRPORT_TAX"));
					product.setCurrencyUnit(rs.getString("CURRENCY_UNIT"));
					product.setExchangeRate(rs.getString("EXCHANGE_RATE"));
					product.setMinimumNumber(rs.getString("MINIMUM_NUMBER"));
					product.setStockQuantity(rs.getString("STOCK_QUANTITY"));
					product.setRemarks(rs.getString("REMARKS"));
					product.setUpdateTime(rs.getTimestamp("UPDATE_TIME"));
					product.setDepartureTime(rs.getTimestamp("DEPARTURE_TIME"));
					product.setArriveTime(rs.getTimestamp("ARRIVAL_TIME"));

				}
			}
		}
		return product;
	}
	
	public Product selectByParticularId(String id) throws SQLException {
		String sql = "SELECT *FROM PRODUCT WHERE PRODUCT_ID  = ?";
		Product product = new Product();
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					product.setProductId(rs.getString("PRODUCT_ID"));
					product.setProductName(rs.getString("PRODUCT_NAME"));
					product.setProductDetail(rs.getString("PRODUCT_CONTENT"));
					product.setProductPrice(rs.getString("PRODUCT_PRICE"));
					product.setAirportTax(rs.getString("AIRPORT_TAX"));
					product.setCurrencyUnit(rs.getString("CURRENCY_UNIT"));
					product.setExchangeRate(rs.getString("EXCHANGE_RATE"));
					product.setMinimumNumber(rs.getString("MINIMUM_NUMBER"));
					product.setStockQuantity(rs.getString("STOCK_QUANTITY"));
					product.setRemarks(rs.getString("REMARKS"));
					product.setUpdateTime(rs.getTimestamp("UPDATE_TIME"));
					product.setDepartureTime(rs.getTimestamp("DEPARTURE_TIME"));
					product.setArriveTime(rs.getTimestamp("ARRIVAL_TIME"));

				}
			}
		}
		return product;
	}

}
