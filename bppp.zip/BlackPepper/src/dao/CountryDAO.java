package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Country;

public class CountryDAO {
	private Connection con;

	public CountryDAO(Connection con) {
		this.con = con;
	}

	public Country selectBycountryId(String countryId) throws SQLException {

		String sql = "SELECT * FROM COUNTRY WHERE COUNTRY_ID =?";
		Country country = new Country();
		try (PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, countryId);

			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					country.setCountryId(rs.getInt("COUNTRY_ID"));
					country.setCountryIdStr(rs.getString("COUNTRY_ID"));
					country.setCountryName(rs.getString("COUNTRY_NAME"));

				}
			}
		}
		return country;
	}

}
