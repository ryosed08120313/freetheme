package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Fright;
import bean.Itinerary;

public class FrightDAO {

	private Connection con;

	public FrightDAO(Connection con) {
		this.con = con;
	}

	// public int insert(Fright fright) throws SQLException {
	// int cnt = 0;
	// String sql = "INSERT INTO ITINERARY(ITINERARY_ID, MEMBER_ID, ITINERARY_NAME,
	// CREATE_TIME, ITINERARY_OVERVIEW, COUNTRY_ID, COUNTRY_NAME )"
	// + "VALUES(?, ?, ?, ?, ?, ?, ?)";
	// System.out.println("itinerary:" + fright);
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	// ps.setString(1, fright.getItineraryId());
	// ps.setString(2, fright.getMemberId());
	// ps.setString(3, itinerary.getItineraryName());
	// ps.setTimestamp(4, itinerary.getCreateTime());
	// ps.setString(5, itinerary.getItineraryOverview());
	// ps.setString(6, itinerary.getCountryId());
	// ps.setString(7, itinerary.getCountryName());
	//
	// cnt = ps.executeUpdate();
	// System.out.println("INSERT INTO ITINERARY:" + cnt);
	// }
	// return cnt;
	// }

	public List<Fright> selectByCityId(int departureCityId, int arrivalCityIdCityId) throws SQLException {

		String sql = "SELECT * FROM FLIGHT_INF WHERE DEPARTURE_CITY_ID = ? AND ARRIVAL_CITY_ID = ?";
		List<Fright> list = new ArrayList<Fright>();

		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, departureCityId);
			ps.setInt(2, arrivalCityIdCityId);

			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					Fright fright = new Fright();
					fright.setFlightId(rs.getString("FLIGHT_ID"));
					fright.setArrivalTimeStamp(rs.getTimestamp("ARRIVAL_TIME"));
					fright.setDepartureTimeStamp(rs.getTimestamp("DEPARTURE_TIME"));
					fright.setDepartureCityIdInt(rs.getInt("DEPARTURE_CITY_ID"));
					fright.setDepartureCityName(rs.getString("DEPARTURE_CITY_NAME"));
					fright.setArrivalCityIdCityIdInt(rs.getInt("ARRIVAL_CITY_ID"));
					fright.setArrivalCityName(rs.getString("ARRIVAL_CITY_NAME"));
					fright.setAirportTaxInt(rs.getInt("AIRPORT_TAX"));
					fright.setCurrencyUnit(rs.getString("CURRENCY_UNIT"));

					list.add(fright);
				}
			}
		}
		return list;
	}

	public Itinerary selectByItineraryId(String itineraryId) throws SQLException {

		String sql = "SELECT * FROM ITINERARY WHERE ITINERARY_ID =?";
		List<Itinerary> list = new ArrayList<Itinerary>();
		Itinerary itinerary = null;
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, itineraryId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					itinerary = new Itinerary();
					itinerary.setMemberId(rs.getString("MEMBER_ID"));
					itinerary.setCreateTime(rs.getTimestamp("CREATE_TIME"));
					itinerary.setCountryId(rs.getString("COUNTRY_ID"));
					itinerary.setItineraryId(rs.getString("ITINERARY_ID"));
					itinerary.setItineraryOverview(rs.getString("ITINERARY_OVERVIEW"));
					itinerary.setItineraryName(rs.getString("ITINERARY_NAME"));
					itinerary.setCountryName(rs.getString("COUNTRY_NAME"));

				}
			}
		}
		return itinerary;
	}

	public Fright selectByFlightId(String flightId) throws SQLException {

		String sql = "SELECT * FROM FLIGHT_INF WHERE FLIGHT_ID = ?";
		Fright flight = null;
		try (PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, flightId);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					flight = new Fright();
					flight.setFlightId(rs.getString("FLIGHT_ID"));
					flight.setArrivalTimeStamp(rs.getTimestamp("ARRIVAL_TIME"));
					flight.setDepartureTimeStamp(rs.getTimestamp("DEPARTURE_TIME"));
					flight.setDepartureCityIdInt(rs.getInt("DEPARTURE_CITY_ID"));
					flight.setDepartureCityName(rs.getString("DEPARTURE_CITY_NAME"));
					flight.setArrivalCityIdCityIdInt(rs.getInt("ARRIVAL_CITY_ID"));
					flight.setArrivalCityName(rs.getString("ARRIVAL_CITY_NAME"));
					flight.setAirportTaxInt(rs.getInt("AIRPORT_TAX"));
					flight.setCurrencyUnit(rs.getString("CURRENCY_UNIT"));

				}
			}
		}
		return flight;
	}

	// public int delete(String ItineraryId) throws SQLException {
	//
	// int cnt = 0;
	// String sql = "DELETE FROM ITINERARY WHERE ITINERARY_ID = ?";
	//
	// Itinerary itinerary = new Itinerary();
	// try (PreparedStatement ps = con.prepareStatement(sql)) {
	//
	// ps.setString(1, itinerary.());
	// cnt = ps.executeUpdate();
	// }

}
