package servlet_KURATA;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayTabsServlet
 */
@WebServlet("/DisplayTabsServlet")
public class DisplayTabsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tabCountStr = request.getParameter("tabCount");
		int tabCount = Integer.parseInt(tabCountStr);
		List<String> tabNameList = new ArrayList<>();

		for(int i = 1; i <= tabCount; i++) {
			tabNameList.add(i + "番目");
		}

		request.setAttribute("tabNameList", tabNameList);
		request.getRequestDispatcher("/tabList.jsp").forward(request, response);
	}

}
