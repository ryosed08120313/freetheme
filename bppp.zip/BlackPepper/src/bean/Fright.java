package bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class Fright implements Serializable {

	private String flightId;
	private String arrivalTime;
	private Timestamp arrivalTimeStamp;
	private String departureTime;
	private Timestamp departureTimeStamp;
	private String departureCityId;
	private int departureCityIdInt;
	private String arrivalCityIdCityId;
	private int arrivalCityIdCityIdInt;
	private String departureCityName;
	private String arrivalCityName;
	private String airportTax;
	private int airportTaxInt;
	private String currencyUnit;
	private double currencyUnitDouble;

	public Fright() {
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Timestamp getArrivalTimeStamp() {
		return arrivalTimeStamp;
	}

	public void setArrivalTimeStamp(Timestamp arrivalTimeStamp) {
		this.arrivalTimeStamp = arrivalTimeStamp;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public Timestamp getDepartureTimeStamp() {
		return departureTimeStamp;
	}

	public void setDepartureTimeStamp(Timestamp departureTimeStamp) {
		this.departureTimeStamp = departureTimeStamp;
	}

	public String getDepartureCityId() {
		return departureCityId;
	}

	public void setDepartureCityId(String departureCityId) {
		this.departureCityId = departureCityId;
	}

	public int getDepartureCityIdInt() {
		return departureCityIdInt;
	}

	public void setDepartureCityIdInt(int departureCityIdInt) {
		this.departureCityIdInt = departureCityIdInt;
	}

	public String getArrivalCityIdCityId() {
		return arrivalCityIdCityId;
	}

	public void setArrivalCityIdCityId(String arrivalCityIdCityId) {
		this.arrivalCityIdCityId = arrivalCityIdCityId;
	}

	public int getArrivalCityIdCityIdInt() {
		return arrivalCityIdCityIdInt;
	}

	public void setArrivalCityIdCityIdInt(int arrivalCityIdCityIdInt) {
		this.arrivalCityIdCityIdInt = arrivalCityIdCityIdInt;
	}

	public String getDepartureCityName() {
		return departureCityName;
	}

	public void setDepartureCityName(String departureCityName) {
		this.departureCityName = departureCityName;
	}

	public String getArrivalCityName() {
		return arrivalCityName;
	}

	public void setArrivalCityName(String arrivalCityName) {
		this.arrivalCityName = arrivalCityName;
	}

	public String getAirportTax() {
		return airportTax;
	}

	public void setAirportTax(String airportTax) {
		this.airportTax = airportTax;
	}

	public int getAirportTaxInt() {
		return airportTaxInt;
	}

	public void setAirportTaxInt(int airportTaxInt) {
		this.airportTaxInt = airportTaxInt;
	}

	public String getCurrencyUnit() {
		return currencyUnit;
	}

	public void setCurrencyUnit(String currencyUnit) {
		this.currencyUnit = currencyUnit;
	}

	public double getCurrencyUnitDouble() {
		return currencyUnitDouble;
	}

	public void setCurrencyUnitDouble(double currencyUnitDouble) {
		this.currencyUnitDouble = currencyUnitDouble;
	}

	@Override
	public String toString() {
		return "Fright [flightId=" + flightId + ", arrivalTime=" + arrivalTime + ", arrivalTimeStamp="
				+ arrivalTimeStamp + ", departureTime=" + departureTime + ", departureTimeStamp=" + departureTimeStamp
				+ ", departureCityId=" + departureCityId + ", departureCityIdInt=" + departureCityIdInt
				+ ", arrivalCityIdCityId=" + arrivalCityIdCityId + ", arrivalCityIdCityIdInt=" + arrivalCityIdCityIdInt
				+ ", departureCityName=" + departureCityName + ", arrivalCityName=" + arrivalCityName + ", airportTax="
				+ airportTax + ", airportTaxInt=" + airportTaxInt + ", currencyUnit=" + currencyUnit
				+ ", currencyUnitDouble=" + currencyUnitDouble + ", getFlightId()=" + getFlightId()
				+ ", getArrivalTime()=" + getArrivalTime() + ", getArrivalTimeStamp()=" + getArrivalTimeStamp()
				+ ", getDepartureTime()=" + getDepartureTime() + ", getDepartureTimeStamp()=" + getDepartureTimeStamp()
				+ ", getDepartureCityId()=" + getDepartureCityId() + ", getDepartureCityIdInt()="
				+ getDepartureCityIdInt() + ", getArrivalCityIdCityId()=" + getArrivalCityIdCityId()
				+ ", getArrivalCityIdCityIdInt()=" + getArrivalCityIdCityIdInt() + ", getDepartureCityName()="
				+ getDepartureCityName() + ", getArrivalCityName()=" + getArrivalCityName() + ", getAirportTax()="
				+ getAirportTax() + ", getAirportTaxInt()=" + getAirportTaxInt() + ", getCurrencyUnit()="
				+ getCurrencyUnit() + ", getCurrencyUnitDouble()=" + getCurrencyUnitDouble() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flightId == null) ? 0 : flightId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fright other = (Fright) obj;
		if (flightId == null) {
			if (other.flightId != null)
				return false;
		} else if (!flightId.equals(other.flightId))
			return false;
		return true;
	}
}