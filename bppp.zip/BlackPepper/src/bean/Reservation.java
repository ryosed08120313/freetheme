package bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class Reservation implements Serializable {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	private String reservationId;
	private String productId;
	private String memberId;
	private Timestamp reservationTime;
	private String reservationNumber;
	private String departureDay;
	// private String returnDay;
	private String TotalAmount;
	private String paymentMethod;
	private String creditcardNumber;
	private String expiryDate;
	private String productPrice;
	private String airportTax;
	private String currencyUnit;
	private String exchangeRate;
	private String itineraryId;
	private String departureFlightId;
	private String arrivalFlightId;

	public String getReservationId() {
		return reservationId;
	}

	public void setReservationId(String reservationId) {
		this.reservationId = reservationId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Timestamp getReservationTime() {
		return reservationTime;
	}

	public void setReservationTime(Timestamp reservationTime) {
		this.reservationTime = reservationTime;
	}

	public String getReservationNumber() {
		return reservationNumber;
	}

	public void setReservationNumber(String reservationNumber) {
		this.reservationNumber = reservationNumber;
	}

	public String getDepartureDay() {
		return departureDay;
	}

	public void setDepartureDay(String departureDay) {
		this.departureDay = departureDay;
	}

	public String getTotalAmount() {
		return TotalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		TotalAmount = totalAmount;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getCreditcardNumber() {
		return creditcardNumber;
	}

	public void setCreditcardNumber(String creditcardNumber) {
		this.creditcardNumber = creditcardNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public String getAirportTax() {
		return airportTax;
	}

	public void setAirportTax(String airportTax) {
		this.airportTax = airportTax;
	}

	public String getCurrencyUnit() {
		return currencyUnit;
	}

	public void setCurrencyUnit(String currencyUnit) {
		this.currencyUnit = currencyUnit;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getItineraryId() {
		return itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	public String getDepartureFlightId() {
		return departureFlightId;
	}

	public void setDepartureFlightId(String departureFlightId) {
		this.departureFlightId = departureFlightId;
	}

	public String getArrivalFlightId() {
		return arrivalFlightId;
	}

	public void setArrivalFlightId(String arrivalFlightId) {
		this.arrivalFlightId = arrivalFlightId;
	}

	@Override
	public String toString() {
		return "Reservation [reservationId=" + reservationId + ", productId=" + productId + ", memberId=" + memberId
				+ ", reservationTime=" + reservationTime + ", reservationNumber=" + reservationNumber
				+ ", departureDay=" + departureDay + ", TotalAmount=" + TotalAmount + ", paymentMethod=" + paymentMethod
				+ ", creditcardNumber=" + creditcardNumber + ", expiryDate=" + expiryDate + ", productPrice="
				+ productPrice + ", airportTax=" + airportTax + ", currenyUnit=" + currencyUnit + ", exchangeRate="
				+ exchangeRate + ", itineraryId=" + itineraryId + ", departureFlightId=" + departureFlightId
				+ ", arrivalFlightId=" + arrivalFlightId + "]";
	}
	//
	// public String getReturnDay() {
	// return returnDay;
	// }
	//
	// public void setReturnDay(String returnDay) {
	// this.returnDay = returnDay;
	// }

}
