package bean;

import java.io.Serializable;

import constants.RankAndPoint;

public class Member implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;
	private String name;
	private String password;
	private String eMail;
	private String zip;
	private String address;
	private String phoneNum;
	private String creditCardNum;
	private String creditCardValidMonth;
	private String creditCardValidYear;
	private String creditCardSecurityCord;
	private String creditCardName;
	private String passportName;
	private String passportNum;
	private int userPoint;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getCreditCardNum() {
		return creditCardNum;
	}

	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}

	public String getCreditCardValidMonth() {
		return creditCardValidMonth;
	}

	public void setCreditCardValidMonth(String creditCardValidMonth) {
		this.creditCardValidMonth = creditCardValidMonth;
	}

	public String getCreditCardValidYear() {
		return creditCardValidYear;
	}

	public void setCreditCardValidYear(String creditCardValidYear) {
		this.creditCardValidYear = creditCardValidYear;
	}

	public String getCreditCardSecurityCord() {
		return creditCardSecurityCord;
	}

	public void setCreditCardSecurityCord(String creditCardSecurityCord) {
		this.creditCardSecurityCord = creditCardSecurityCord;
	}

	public String getCreditCardName() {
		return creditCardName;
	}

	public void setCreditCardName(String creditCardName) {
		this.creditCardName = creditCardName;
	}

	public String getPassportName() {
		return passportName;
	}

	public void setPassportName(String passportName) {
		this.passportName = passportName;
	}

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public int getUserPoint() {
		return userPoint;
	}

	public void setUserPoint(int userPoint) {
		this.userPoint = userPoint;
	}

	public String getMemberRank() {
		return RankAndPoint.userRank(userPoint);
	}

	public int getNecessaryPoint() {
		return RankAndPoint.toNextRank(userPoint);
	}

	public double getLimitView() {
		return RankAndPoint.limitView(userPoint);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Member [id=" + id + ", name=" + name + ", password=" + password + ", eMail=" + eMail + ", zip=" + zip
				+ ", address=" + address + ", phoneNum=" + phoneNum + ", creditCardNum=" + creditCardNum
				+ ", creditCardValidMonth=" + creditCardValidMonth + ", creditCardValidYear=" + creditCardValidYear
				+ ", creditCardSecurityCord=" + creditCardSecurityCord + ", creditCardName=" + creditCardName
				+ ", passportName=" + passportName + ", passportNum=" + passportNum + ", userPoint=" + userPoint + "]";
	}

}
