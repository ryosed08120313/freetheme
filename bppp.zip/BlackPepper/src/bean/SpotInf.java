package bean;

import java.io.Serializable;

public class SpotInf implements Serializable {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	private String spotInfId;
	private String dayNumber;
	private String itineraryId;
	private String timeState;
	private String sequenceInf;
	private String spotId;
	private String tourContent;
	private String tourName;
	private String tourPrice;

	public String getSpotInfId() {
		return spotInfId;
	}

	public void setSpotInfId(String spotInfId) {
		this.spotInfId = spotInfId;
	}

	public String getDayNumber() {
		return dayNumber;
	}

	public void setDayNumber(String dayNumber) {
		this.dayNumber = dayNumber;
	}

	public String getItineraryId() {
		return itineraryId;
	}

	public void setItineraryId(String itineraryId) {
		this.itineraryId = itineraryId;
	}

	public String getTimeState() {
		return timeState;
	}

	public void setTimeState(String timeState) {
		this.timeState = timeState;
	}

	public String getSequenceInf() {
		return sequenceInf;
	}

	public void setSequenceInf(String sequenceInf) {
		this.sequenceInf = sequenceInf;
	}

	public String getSpotId() {
		return spotId;
	}

	public void setSpotId(String spotId) {
		this.spotId = spotId;
	}

	public String getTourContent() {
		return tourContent;
	}

	public void setTourContent(String tourContent) {
		this.tourContent = tourContent;
	}

	public String getTourName() {
		return tourName;
	}

	public void setTourName(String tourName) {
		this.tourName = tourName;
	}

	public String getTourPrice() {
		return tourPrice;
	}

	public void setTourPrice(String tourPrice) {
		this.tourPrice = tourPrice;
	}

	@Override
	public String toString() {
		return "SpotInf [spotInfId=" + spotInfId + ", dayNumber=" + dayNumber + ", itineraryId=" + itineraryId
				+ ", timeState=" + timeState + ", sequenceInf=" + sequenceInf + ", spotId=" + spotId + ", tourContent="
				+ tourContent + ", tourName=" + tourName + ", tourPrice=" + tourPrice + "]";
	}

}
