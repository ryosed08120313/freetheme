package bean;

import java.io.Serializable;

/**
 * 
 * @author 鈴木
 *
 *         商品（パッケージツアー）のbean
 *
 */
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	private String productId;
	private String productName;
	private String productDetail;
	private String productPrice;
	private java.sql.Timestamp updateTime;
	private String airportTax;
	private String currencyUnit;
	private String exchangeRate;
	private String minimumNumber;
	private String stockQuantity;
	// remarksには国名を入れる
	private String remarks;
	private java.sql.Timestamp departureTime;
	private java.sql.Timestamp arriveTime;

	public Product() {
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDetail() {
		return productDetail;
	}

	public void setProductDetail(String productDetail) {
		this.productDetail = productDetail;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public java.sql.Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(java.sql.Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public String getAirportTax() {
		return airportTax;
	}

	public void setAirportTax(String airportTax) {
		this.airportTax = airportTax;
	}

	public String getCurrencyUnit() {
		return currencyUnit;
	}

	public void setCurrencyUnit(String currencyUnit) {
		this.currencyUnit = currencyUnit;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getMinimumNumber() {
		return minimumNumber;
	}

	public void setMinimumNumber(String minimumNumber) {
		this.minimumNumber = minimumNumber;
	}

	public String getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(String stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public java.sql.Timestamp getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(java.sql.Timestamp departureTime) {
		this.departureTime = departureTime;
	}

	public java.sql.Timestamp getArriveTime() {
		return arriveTime;
	}

	public void setArriveTime(java.sql.Timestamp arriveTime) {
		this.arriveTime = arriveTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDetail=" + productDetail
				+ ", productPrice=" + productPrice + ", updateTime=" + updateTime + ", airportTax=" + airportTax
				+ ", currencyUnit=" + currencyUnit + ", exchangeRate=" + exchangeRate + ", minimumNumber="
				+ minimumNumber + ", stockQuantity=" + stockQuantity + ", remarks=" + remarks + ", departureTime="
				+ departureTime + ", arriveTime=" + arriveTime + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		return true;
	}
}