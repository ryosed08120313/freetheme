package bean;

import java.io.Serializable;

public class OptionalTour implements Serializable {

	private static final long serialVersionUID = 1L;
	String tourId;
	String tourName;
	String tourContent;
	String tourPrice;

	public String getTourId() {
		return tourId;
	}

	public void setTourId(String tourId) {
		this.tourId = tourId;
	}

	public String getTourName() {
		return tourName;
	}

	public void setTourName(String tourName) {
		this.tourName = tourName;
	}

	public String getTourContent() {
		return tourContent;
	}

	public void setTourContent(String tourContent) {
		this.tourContent = tourContent;
	}

	public String getTourPrice() {
		return tourPrice;
	}

	public void setTourPrice(String tourPrice) {
		this.tourPrice = tourPrice;
	}

	@Override
	public String toString() {
		return "OptionalTour [tourId=" + tourId + ", tourName=" + tourName + ", tourContent=" + tourContent
				+ ", tourPrice=" + tourPrice + "]";
	}

}