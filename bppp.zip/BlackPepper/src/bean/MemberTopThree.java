package bean;

import java.io.Serializable;
import java.util.List;

import constants.RankAndPoint;

public class MemberTopThree implements Serializable {

	private static final long serialVersionUID = 1L;
	private String memberId;
	private String memberName;
	private int memberRanking;
	private int memberPoint;
	private String memberRank;
	private List<Itinerary> ItineraryL;
	private int necessaryPoint;

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public int getNecessaryPoint() {
		return necessaryPoint;
	}

	public void setNecessaryPoint(int necessaryPoint) {
		this.necessaryPoint = RankAndPoint.toNextRank(memberPoint);
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public int getMemberRanking() {
		return memberRanking;
	}

	public void setMemberRanking(int memberRanking) {
		this.memberRanking = memberRanking;
	}

	public int getMemberPoint() {
		return memberPoint;
	}

	public void setMemberPoint(int memberPoint) {
		this.memberPoint = memberPoint;
	}

	public String getMemberRank() {
		return memberRank;
	}

	public void setMemberRank(int memberRank) {
		this.memberRank = RankAndPoint.userRank(memberPoint);
	}

	public List<Itinerary> getItineraryL() {
		return ItineraryL;
	}

	public void setItineraryL(List<Itinerary> itineraryL) {
		ItineraryL = itineraryL;
	}

	@Override
	public String toString() {
		return "MemberTopThree [memberId=" + memberId + ", memberName=" + memberName + ", memberRanking="
				+ memberRanking + ", memberPoint=" + memberPoint + ", memberRank=" + memberRank + ", ItineraryL="
				+ ItineraryL + ", necessaryPoint=" + necessaryPoint + "]";
	}
}
