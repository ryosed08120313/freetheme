package bean;

public class Country {

	private static final long serialVersionUID = 1L;

	private int countryId;
	private String countryIdStr;
	private String countryName;

	public Country() {
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public String getCountryIdStr() {
		return countryIdStr;
	}

	public void setCountryIdStr(String countryIdStr) {
		this.countryIdStr = countryIdStr;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + countryId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		if (countryId != other.countryId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Country [countryId=" + countryId + ", countryIdStr=" + countryIdStr + ", countryName=" + countryName
				+ "]";
	}

}
