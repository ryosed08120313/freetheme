package bean;

import java.io.Serializable;

public class Spot implements Serializable {
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	private String spotId;
	private String spotName;
	private String memberId;
	private String cityId;
	private String tour1Id;
	private String tour2Id;
	private String tour3Id;
	private String spotContent;
	private String category1Id;
	private String category2Id;
	private String category3Id;
	private String category4Id;
	private String category5Id;
	private String category6Id;
	private String category1Name;
	private String category2Name;
	private String category3Name;
	private String category4Name;
	private String category5Name;
	private String category6Name;
	private String countryName;
	//緯度経度を追加（倉田）
	private String latLon;

	public String getSpotId() {
		return spotId;
	}

	public void setSpotId(String spotId) {
		this.spotId = spotId;
	}

	public String getSpotName() {
		return spotName;
	}

	public void setSpotName(String spotName) {
		this.spotName = spotName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getTour1Id() {
		return tour1Id;
	}

	public void setTour1Id(String tour1Id) {
		this.tour1Id = tour1Id;
	}

	public String getTour2Id() {
		return tour2Id;
	}

	public void setTour2Id(String tour2Id) {
		this.tour2Id = tour2Id;
	}

	public String getTour3Id() {
		return tour3Id;
	}

	public void setTour3Id(String tour3Id) {
		this.tour3Id = tour3Id;
	}

	public String getSpotContent() {
		return spotContent;
	}

	public void setSpotContent(String spotContent) {
		this.spotContent = spotContent;
	}

	public String getCategory1Id() {
		return category1Id;
	}

	public void setCategory1Id(String category1Id) {
		this.category1Id = category1Id;
	}

	public String getCategory2Id() {
		return category2Id;
	}

	public void setCategory2Id(String category2Id) {
		this.category2Id = category2Id;
	}

	public String getCategory3Id() {
		return category3Id;
	}

	public void setCategory3Id(String category3Id) {
		this.category3Id = category3Id;
	}

	public String getCategory4Id() {
		return category4Id;
	}

	public void setCategory4Id(String category4Id) {
		this.category4Id = category4Id;
	}

	public String getCategory5Id() {
		return category5Id;
	}

	public void setCategory5Id(String category5Id) {
		this.category5Id = category5Id;
	}

	public String getCategory6Id() {
		return category6Id;
	}

	public void setCategory6Id(String category6Id) {
		this.category6Id = category6Id;
	}

	public String getCategory1Name() {
		return category1Name;
	}

	public void setCategory1Name(String category1Name) {
		this.category1Name = category1Name;
	}

	public String getCategory2Name() {
		return category2Name;
	}

	public void setCategory2Name(String category2Name) {
		this.category2Name = category2Name;
	}

	public String getCategory3Name() {
		return category3Name;
	}

	public void setCategory3Name(String category3Name) {
		this.category3Name = category3Name;
	}

	public String getCategory4Name() {
		return category4Name;
	}

	public void setCategory4Name(String category4Name) {
		this.category4Name = category4Name;
	}

	public String getCategory5Name() {
		return category5Name;
	}

	public void setCategory5Name(String category5Name) {
		this.category5Name = category5Name;
	}

	public String getCategory6Name() {
		return category6Name;
	}

	public void setCategory6Name(String category6Name) {
		this.category6Name = category6Name;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
	//緯度経度を追加（倉田）
	public String getLatLon() {
		return latLon;
	}

	//緯度経度を追加（倉田）
	public void setLatLon(String latLon) {
		this.latLon = latLon;
	}

	@Override
	public String toString() {
		return "Spot [spotId=" + spotId + ", spotName=" + spotName + ", memberId=" + memberId + ", cityId=" + cityId
				+ ", tour1Id=" + tour1Id + ", tour2Id=" + tour2Id + ", tour3Id=" + tour3Id + ", spotContent="
				+ spotContent + ", category1Id=" + category1Id + ", category2Id=" + category2Id + ", category3Id="
				+ category3Id + ", category4Id=" + category4Id + ", category5Id=" + category5Id + ", category6Id="
				+ category6Id + ", category1Name=" + category1Name + ", category2Name=" + category2Name
				+ ", category3Name=" + category3Name + ", category4Name=" + category4Name + ", category5Name="
				+ category5Name + ", category6Name=" + category6Name + ", countryName=" + countryName + ", latLon=" + latLon + "]";
	}

}
