//package TestServlet;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.SQLException;
//
//import javax.naming.NamingException;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import bean.Member;
//import dao.MembersDAO;
//import ds.ConnectionManager;
//
///**
// * 従業員情報登録用サーブレット
// */
//@WebServlet("/InsertMembersServlet")
//public class InsertMembersServlet extends HttpServlet {
//
//	protected void doPost(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		// String url = ConstURL.InsertDoneMembers_PATH;
//		// String errorURL = ConstURL.InsertInputMembers_PATH;
//		String errorMessage = "入力した会員IDはすでに使用されています。";
//		String Id = request.getParameter("txtId");
//		String Name = request.getParameter("txtName");
//
//		try (Connection con = ConnectionManager.getConnection()) {
//
//			try {
//				MembersDAO dao = new MembersDAO(con);
//
//				Member member = new Member();
//				member.setId(Id);
//				member.setName(Name);
//				dao.insert(member);
//				request.setAttribute("member", member);
//
//			} finally {
//
//			}
//
//		} catch (SQLException | NamingException e) {
//			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
//		}
//
//		// request.getRequestDispatcher(url).forward(request, response);
//	}
//}
