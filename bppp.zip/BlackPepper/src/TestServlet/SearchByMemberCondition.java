//package TestServlet;
//
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.naming.NamingException;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import bean.Member;
//import dao.MembersDAO;
//import ds.ConnectionManager;
//
///**
// * Servlet implementation class SearchByMemberId
// */
//@WebServlet("/SearchByMemberCondition")
//public class SearchByMemberCondition extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//	/**
//	 * @see HttpServlet#HttpServlet()
//	 */
//	public SearchByMemberCondition() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
//	 *      response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String url = "\\SearchMemberPage.jsp";
//		String errorMessage = "年代を選んでくたさい！";
//		String name = request.getParameter("name");
//		String spell = request.getParameter("spell");
//		String sex = request.getParameter("sex");
//		int[] ageIntList = { 0, 0, 0, 0, 0, 0, 0 };
//		String[] ageStringList;
//		ageStringList = request.getParameterValues("age");
//		if (ageStringList != null) {
//			for (int i = 0; i < ageStringList.length; i++) {
//				ageIntList[i] = Integer.parseInt(ageStringList[i]);
//			}
//		}
//
//		if (ageStringList == null) {
//			request.setAttribute("errorMessage", errorMessage);
//			request.getRequestDispatcher(url).forward(request, response);
//			return;
//		}
//
//		try (Connection con = ConnectionManager.getConnection()) {
//			MembersDAO dao = new MembersDAO(con);
//			List<Member> memberList = new ArrayList<Member>();
//
//			memberList = dao.selectByCondition(name, spell, sex, ageIntList);
//			request.setAttribute("memberList", memberList);
//		} catch (SQLException | NamingException e) {
//			throw new ServletException(e.getMessage() + ":データソースの設定が正しく行われていません");
//		}
//
//		request.getRequestDispatcher(url).forward(request, response);
//
//	}
//
//}
