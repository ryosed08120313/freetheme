package TestServlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 従業員情報登録画面表示用サーブレット
 */
@WebServlet("/InsertInputPrivateSpotServlet")
public class InsertInputPrivateSpotServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String errorURL = "ViewMembersServlet";
		String id = request.getParameter("id");

		if (id == null || id.isEmpty()) {

			String error = "追加したい会員の行を選んでください。";
			request.setAttribute("error", error);
			request.getRequestDispatcher(errorURL).forward(request, response);
			return;
		}

		request.setAttribute("id", id);

		// String url = ConstURL.InsertInputPrivateSpot_PATH;
		// request.getRequestDispatcher(url).forward(request, response);

	}

}
