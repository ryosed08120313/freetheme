package TestServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Member;
import dao.MembersDAO;
import ds.ConnectionManager;

/**
 * 従業員情報変更画面表示用サーブレット
 */
@WebServlet("/ConfirmMemberServlet")
public class ConfirmMemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");

		try (Connection con = ConnectionManager.getConnection()) {

			Member member = new Member();

//			MembersDAO dao = new MembersDAO(con);
//			member = dao.confirmById1(id);
//			request.setAttribute("member", member);

		} catch (SQLException | NamingException e) {
			throw new ServletException(e);
		}

		request.getRequestDispatcher("\\confirmMemberPage.jsp").forward(request, response);

	}

}
